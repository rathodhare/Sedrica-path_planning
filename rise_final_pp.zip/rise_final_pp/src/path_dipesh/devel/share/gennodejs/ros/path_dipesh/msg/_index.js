
"use strict";

let msg3 = require('./msg3.js');
let msg2 = require('./msg2.js');
let test = require('./test.js');

module.exports = {
  msg3: msg3,
  msg2: msg2,
  test: test,
};
