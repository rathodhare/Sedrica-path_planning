// Auto-generated. Do not edit!

// (in-package path_dipesh.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let test = require('./test.js');

//-----------------------------------------------------------

class msg2 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.lane_coefficients = null;
    }
    else {
      if (initObj.hasOwnProperty('lane_coefficients')) {
        this.lane_coefficients = initObj.lane_coefficients
      }
      else {
        this.lane_coefficients = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type msg2
    // Serialize message field [lane_coefficients]
    // Serialize the length for message field [lane_coefficients]
    bufferOffset = _serializer.uint32(obj.lane_coefficients.length, buffer, bufferOffset);
    obj.lane_coefficients.forEach((val) => {
      bufferOffset = test.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type msg2
    let len;
    let data = new msg2(null);
    // Deserialize message field [lane_coefficients]
    // Deserialize array length for message field [lane_coefficients]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.lane_coefficients = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.lane_coefficients[i] = test.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.lane_coefficients.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'path_dipesh/msg2';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5814eeb6c12301877fa27ffdff290742';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    test[] lane_coefficients
    
    ================================================================================
    MSG: path_dipesh/test
    float64 coeff
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new msg2(null);
    if (msg.lane_coefficients !== undefined) {
      resolved.lane_coefficients = new Array(msg.lane_coefficients.length);
      for (let i = 0; i < resolved.lane_coefficients.length; ++i) {
        resolved.lane_coefficients[i] = test.Resolve(msg.lane_coefficients[i]);
      }
    }
    else {
      resolved.lane_coefficients = []
    }

    return resolved;
    }
};

module.exports = msg2;
