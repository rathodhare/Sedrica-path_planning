// Auto-generated. Do not edit!

// (in-package path_dipesh.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let msg2 = require('./msg2.js');

//-----------------------------------------------------------

class msg3 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.coefficients = null;
    }
    else {
      if (initObj.hasOwnProperty('coefficients')) {
        this.coefficients = initObj.coefficients
      }
      else {
        this.coefficients = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type msg3
    // Serialize message field [coefficients]
    // Serialize the length for message field [coefficients]
    bufferOffset = _serializer.uint32(obj.coefficients.length, buffer, bufferOffset);
    obj.coefficients.forEach((val) => {
      bufferOffset = msg2.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type msg3
    let len;
    let data = new msg3(null);
    // Deserialize message field [coefficients]
    // Deserialize array length for message field [coefficients]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.coefficients = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.coefficients[i] = msg2.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.coefficients.forEach((val) => {
      length += msg2.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'path_dipesh/msg3';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f02df5118b0b45ff01cac246661e066e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    msg2[] coefficients
    
    ================================================================================
    MSG: path_dipesh/msg2
    test[] lane_coefficients
    
    ================================================================================
    MSG: path_dipesh/test
    float64 coeff
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new msg3(null);
    if (msg.coefficients !== undefined) {
      resolved.coefficients = new Array(msg.coefficients.length);
      for (let i = 0; i < resolved.coefficients.length; ++i) {
        resolved.coefficients[i] = msg2.Resolve(msg.coefficients[i]);
      }
    }
    else {
      resolved.coefficients = []
    }

    return resolved;
    }
};

module.exports = msg3;
