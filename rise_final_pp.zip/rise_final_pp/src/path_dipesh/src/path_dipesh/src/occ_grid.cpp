#include "ros/ros.h"
#include "std_msgs/String.h"
#include <bits/stdc++.h>
#include <cmath>
#include <std_msgs/Float64MultiArray.h>
#include "nav_msgs/OccupancyGrid.h"
#include <std_msgs/Float64.h>

using namespace std;

// Grid (x*y)=(200*400)
const float traversable_dist_lowerlim=1; //1.3m
const float traversable_dist_upperlim=4; //2.6m
const float map_resolution=0.05; //5 cm
const int lane_cost=7; //arbitrary for now
const int y=400;

const float x1=25,x2=40,x3=75;
ros::Publisher viz;
ros::Publisher publi_index;
vector<int> traversable_lane_index;
vector<float> dist;	//dist[i]  -->> dist between ith lane and (i+1)th lane
vector<float> angle;	//angle of ith traversable path
vector<int> last_line;	//last row of the occupancy grid
std_msgs::Float64MultiArray final_path_index;
vector<vector<float> > quad_coefficients;
float a1,a2,a3; //coefficients of quadratic eq. of lane
std::vector<float> v;

nav_msgs::OccupancyGrid create_rviz_map()//Function for vizualization
{
	nav_msgs::OccupancyGrid custom_map;//<-Custom map is made from the given lane equations
	bool map_received = true;
	//nav_msgs::OccupancyGrid custom_map;
	custom_map.info.width = 600;
	int map_breadth_count = 600;
	custom_map.info.height = 400;
	int map_height_count = 400; 
	custom_map.info.resolution = 0.05;
	int map_res=0.05;
	//cout<<custom_map.info.height<<" "<<custom_map.info.width<<endl;
	//cout<<map_height_count<<" "<<map_breadth_count<<endl;
	for(int i=0;i<map_height_count;i++)//Adding all 0s
    {
      for(int j=0;j<map_breadth_count;j++)
      {
         custom_map.data.push_back(0);
      }
    }
	/*for(int i=0;i<map_height_count;i++)
    {
      for(int j=0;j<map_breadth_count;j++)
      {
        custom_map.data[i*map_height_count+j]=msg.data[i*map_height_count+j];
         //cout<<custom_map.data[i*map_height_count+j];
      }
    }*/
    //cout<<traversable_lane_index.size();
    //Doing if (f1(y)<x<f2(y)) => color (x,y)) where y1, y2 are the 2 functionsof adjecent lanes
	for(int j=0;j<traversable_lane_index.size();j++){
		//cout<<j<<endl;
		for(int i=0;i<(map_height_count)*(map_breadth_count);i++)
		{
			//cout<<"j "<<j<<endl;
			int y=i/map_breadth_count;
			int x=i%map_breadth_count;
			float poll=(quad_coefficients[traversable_lane_index[j]][1]*y*y)+(quad_coefficients[traversable_lane_index[j]][2]*y)+(quad_coefficients[traversable_lane_index[j]][3]);
			float polu=(quad_coefficients[traversable_lane_index[j]+1][1]*y*y)+(quad_coefficients[traversable_lane_index[j]+1][2]*y)+(quad_coefficients[traversable_lane_index[j]+1][3]);
			//cout<<x<<" "<<y<<" "<<poll<<" "<<polu<<endl;
			if(poll<x && x<polu){
				//cout<<"Yes"<<x<<" "<<y<<endl;
				custom_map.data[i]=90;
			}
			else if((poll+2)>=x  && (poll-2)<=x|| (polu+2)>=x && (polu-2)<=x )custom_map.data[i]=200;
		}
	}
	//lane index stores coeff of traversible lane
	traversable_lane_index.clear();
	return custom_map;
}

//Doing all the cout stuff and making all arrays including traversible_lanes array here
void lane_indexing(){

	for(int i=0;i<quad_coefficients.size();i++){
		int a=0;
		angle.push_back(a);
	}	

	// for(int i=0;i<last_line.size();i++){
	// 	if(last_line[i]==lane_cost) lane_index.push_back(i);
		
	// }

	for(int i=0;(i<last_line.size()-1)&&last_line.size();i++){
		float dist_betn_lanes=(last_line[i+1]-last_line[i])*(map_resolution);
		dist.push_back(dist_betn_lanes);
		cout<<"last_line "<<last_line[i]<<' '<<last_line[i+1]<<' '<<dist_betn_lanes<<" meter\n";	
	}
	
	
	for(int i=0;i<dist.size();i++){
		float traversable_distance=cos(angle[i]) *dist[i];
		if(traversable_distance>traversable_dist_lowerlim && traversable_distance<traversable_dist_upperlim){
			traversable_lane_index.push_back(i);
			cout<<"oh\n";
		}
	
		cout<<"distance betn 2 lanes "<<traversable_distance<<endl;
	}
	for(int i=0;i<traversable_lane_index.size();i++){
		cout<<"traversable_lane_index "<<traversable_lane_index[i]<<" traversable_lane_dist "<<dist[i]<<endl;
		final_path_index.data.push_back(traversable_lane_index[i]);
		final_path_index.data.push_back(dist[i]);
		final_path_index.data.push_back(-1);
	}
	//traversable lane index and then distance of that path followed by -1 for separation

	dist.clear();
	last_line.clear();

}

//This function is perfectly fine. No need to touch
void quad_manipulation(const std_msgs::Float64MultiArray::ConstPtr& tra){
	// ::path_dipesh::msg2 a= coefficients->coefficients[1];
	// ::path_dipesh::test b= a.lane_coefficients[0];
	// // ::path_dipesh::test b= a->lane_coefficients[0];
	// //cout<<b<<endl;
	// // ::path_dipesh::msg2 a= coefficients->coefficients[0];
	//quad_coefficients[0][0]=tra->data[1];

	quad_coefficients.clear();
	for(int i=0;i<4;i++){
		quad_coefficients.push_back(vector<float> ());
		for(int j=0;j<4;j++){
			quad_coefficients[i].push_back(tra->data[i*4+j]);
		}
	}
	for(int i=0;i<4;i++){
		for(int j=0;j<4;j++){
			cout<<quad_coefficients[i][j]<<" ";
		}
		cout<<endl;
	}
	// THE MATRIX	
	// for(int i=0;i<3;i++){
	// 	for(int j=0;j<4;j++){
	// 		cout<<quad_coefficients[i][j]<<" , ";
	// 	}
	// 	cout<<endl;
	// }	

	// cout<<"size "<<quad_coefficients.size()<<endl;
	// for(int i=0;i<sizeof(coefficients->coefficients[1]);i++){
	// 	cout<<i<<endl;
		// cout<<a.lane_coefficients[i]<<endl;
	 // }
	//after adding data in vectors
	
	for(int i=0;i<quad_coefficients.size();i++){
		float x= quad_coefficients[i][1]*y*y + quad_coefficients[i][2]*y + quad_coefficients[i][3];
		last_line.push_back(x);
		cout<<" x("<<i+1<<") = "<<last_line[i]<<endl;
	}

	// last_line.clear();
	// last_line.push_back(x1);
	// last_line.push_back(x2);
	// last_line.push_back(x3);	

	// sort(last_line.begin(),last_line.end());
	// cout<<last_line.size()<<endl;
	publi_index.publish(final_path_index);
	lane_indexing();
	nav_msgs::OccupancyGrid custom_map=create_rviz_map();
	viz.publish(custom_map);
}

int main(int argc, char **argv){
	ros::init(argc, argv, "occ_grid");
	ros::NodeHandle n;
	ros::Subscriber quad_coeff=n.subscribe("/Lane_coefficients",1,quad_manipulation);
	//ros::Subscriber occgrid=n.subscribe("/Lane_Occupancy_Grid",10,create_rviz_map);
	publi_index = n.advertise<std_msgs::Float64MultiArray>("path_index", 1000);
	viz = n.advertise<nav_msgs::OccupancyGrid>("visualize", 10);//<- Used for vizualization
	ros::Rate loop_rate(100000);

	while (ros::ok()){
		//custom_map.clear();
		ros::spinOnce();
		loop_rate.sleep();
	}



}

// 0 7 0 7 7 0 0 7 7
// 0 0 0 0 0 0 0 0 0