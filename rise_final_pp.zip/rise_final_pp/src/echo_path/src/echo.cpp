#include <iostream>
#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;

ros::Publisher echoed_path;
nav_msgs::Path echo_path;
geometry_msgs::PoseStamped temp;

void echo(const nav_msgs::Path::ConstPtr& path){
	echo_path.poses.clear();
	for(int i=0;i<path->poses.size();i++){
		temp = path->poses[i];
		echo_path.poses.push_back(temp);
	}
	echoed_path.publish(echo_path);
}

int main(int argc, char** argv){
	ros::init(argc,argv,"echoed_path");
	ros::NodeHandle n;
	ros::Subscriber path = n.subscribe("/path",1,echo);
	echoed_path = n.advertise<nav_msgs::Path>("/echoed_path",1);
	int count = 0;
	ros::Rate loop_rate(200);
	while(ros::ok()){
		ros::spinOnce();
		loop_rate.sleep();
		++count;
	}
	return 0;
}